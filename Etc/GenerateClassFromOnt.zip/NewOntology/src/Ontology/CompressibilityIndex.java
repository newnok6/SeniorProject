package Ontology;
import java.util.ArrayList;

import java.sql.Time;
public class CompressibilityIndex extends FlowabilityIndicator
{
BulkDensity  bulkdensityproperty;
TappedDensity  tappeddensityproperty;
public BulkDensity  getBulkdensityproperty()
{
return this.bulkdensityproperty;
}public void setBulkdensityproperty ( BulkDensity bulkdensityproperty)
{
this.bulkdensityproperty = bulkdensityproperty;
}

public TappedDensity  getTappeddensityproperty()
{
return this.tappeddensityproperty;
}public void setTappeddensityproperty ( TappedDensity tappeddensityproperty)
{
this.tappeddensityproperty = tappeddensityproperty;
}

}