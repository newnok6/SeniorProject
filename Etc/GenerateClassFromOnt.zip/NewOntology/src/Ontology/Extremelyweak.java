package Ontology;
import java.util.ArrayList;

import java.sql.Time;
public class Extremelyweak extends pKa
{
float  maximumpkaproperty;
float  minimalpka = 14f;
public float  getMaximumpkaproperty()
{
return this.maximumpkaproperty;
}public void setMaximumpkaproperty ( float maximumpkaproperty)
{
this.maximumpkaproperty = maximumpkaproperty;
}

public float  getMinimalpka()
{
return this.minimalpka;
}public void setMinimalpka ( float minimalpka)
{
this.minimalpka = minimalpka;
}

}