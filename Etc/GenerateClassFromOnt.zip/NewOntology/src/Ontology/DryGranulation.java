package Ontology;
import java.util.ArrayList;

import java.sql.Time;
public class DryGranulation extends Granulation
{
Compression  unitoperationproperty;
public Compression  getUnitoperationproperty()
{
return this.unitoperationproperty;
}public void setUnitoperationproperty ( Compression unitoperationproperty)
{
this.unitoperationproperty = unitoperationproperty;
}

}