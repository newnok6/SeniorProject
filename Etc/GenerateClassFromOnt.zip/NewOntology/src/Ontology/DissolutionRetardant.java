package Ontology;
import java.util.ArrayList;

import java.sql.Time;
public class DissolutionRetardant
{
Substance  substance;
DissolutionRetardantFunction  dissolutionretardantfunction;
public Substance  getSubstance()
{
return this.substance;
}public void setSubstance ( Substance substance)
{
this.substance = substance;
}

public DissolutionRetardantFunction  getDissolutionretardantfunction()
{
return this.dissolutionretardantfunction;
}public void setDissolutionretardantfunction ( DissolutionRetardantFunction dissolutionretardantfunction)
{
this.dissolutionretardantfunction = dissolutionretardantfunction;
}

}