package Ontology;
import java.util.ArrayList;

import java.sql.Time;
public class DisintegrationTime extends QualityControl
{
Time  valueproperty;
public Time  getValue()
{
return this.valueproperty;
}public void setValue ( Time valueproperty)
{
this.valueproperty = valueproperty;
}

}