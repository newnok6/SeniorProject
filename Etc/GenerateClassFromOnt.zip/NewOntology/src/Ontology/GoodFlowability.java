package Ontology;
import java.util.ArrayList;

import java.sql.Time;
public class GoodFlowability extends Flowability
{
}