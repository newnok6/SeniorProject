package Ontology;
import java.util.ArrayList;

import java.sql.Time;
public class Glidant
{
Substance  substance;
GlidantFunction  glidantfunction;
public Substance  getSubstance()
{
return this.substance;
}public void setSubstance ( Substance substance)
{
this.substance = substance;
}

public GlidantFunction  getGlidantfunction()
{
return this.glidantfunction;
}public void setGlidantfunction ( GlidantFunction glidantfunction)
{
this.glidantfunction = glidantfunction;
}

}