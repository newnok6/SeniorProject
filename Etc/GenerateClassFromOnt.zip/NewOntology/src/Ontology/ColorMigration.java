package Ontology;
import java.util.ArrayList;

import java.sql.Time;
public class ColorMigration extends CoatingProblem
{
}