package Ontology;
import java.util.ArrayList;

import java.sql.Time;
public class Flowability extends SubstanceProperty
{
CompressibilityIndex  flowability;
HausnerRatio  flowability;
AngleOfRepose  flowability;
public CompressibilityIndex  getFlowability()
{
return this.flowability;
}public void setFlowability ( CompressibilityIndex flowability)
{
this.flowability = flowability;
}

public HausnerRatio  getFlowability()
{
return this.flowability;
}public void setFlowability ( HausnerRatio flowability)
{
this.flowability = flowability;
}

public AngleOfRepose  getFlowability()
{
return this.flowability;
}public void setFlowability ( AngleOfRepose flowability)
{
this.flowability = flowability;
}

}