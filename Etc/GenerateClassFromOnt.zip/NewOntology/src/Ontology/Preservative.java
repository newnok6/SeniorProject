package Ontology;
import java.util.ArrayList;

import java.sql.Time;
public class Preservative
{
Substance  substance;
PreservativeFunction  preservativefunction;
public Substance  getSubstance()
{
return this.substance;
}public void setSubstance ( Substance substance)
{
this.substance = substance;
}

public PreservativeFunction  getPreservativefunction()
{
return this.preservativefunction;
}public void setPreservativefunction ( PreservativeFunction preservativefunction)
{
this.preservativefunction = preservativefunction;
}

}