package Ontology;
import java.util.ArrayList;

import java.sql.Time;
public class ThickeningAgent
{
Substance  substance;
ThickeningAgentProperty  thickeningagentproperty;
public Substance  getSubstance()
{
return this.substance;
}public void setSubstance ( Substance substance)
{
this.substance = substance;
}

public ThickeningAgentProperty  getThickeningagentproperty()
{
return this.thickeningagentproperty;
}public void setThickeningagentproperty ( ThickeningAgentProperty thickeningagentproperty)
{
this.thickeningagentproperty = thickeningagentproperty;
}

}