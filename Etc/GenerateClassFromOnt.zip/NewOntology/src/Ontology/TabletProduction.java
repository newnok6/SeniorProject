package Ontology;
import java.util.ArrayList;

import java.sql.Time;
public class TabletProduction extends PharmaceuticalProduction
{
TabletProcess  processproperty;
TabletFormulation  formulationproperty;
public TabletProcess  getProcessproperty()
{
return this.processproperty;
}public void setProcessproperty ( TabletProcess processproperty)
{
this.processproperty = processproperty;
}

public TabletFormulation  getFormulationproperty()
{
return this.formulationproperty;
}public void setFormulationproperty ( TabletFormulation formulationproperty)
{
this.formulationproperty = formulationproperty;
}

}