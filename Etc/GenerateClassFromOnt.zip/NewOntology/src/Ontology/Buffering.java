package Ontology;
import java.util.ArrayList;

import java.sql.Time;
public class Buffering
{
Substance  substance;
BufferingFunction  bufferingfunction;
public Substance  getSubstance()
{
return this.substance;
}public void setSubstance ( Substance substance)
{
this.substance = substance;
}

public BufferingFunction  getBufferingfunction()
{
return this.bufferingfunction;
}public void setBufferingfunction ( BufferingFunction bufferingfunction)
{
this.bufferingfunction = bufferingfunction;
}

}