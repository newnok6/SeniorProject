package Ontology;
import java.util.ArrayList;

import java.sql.Time;
public class PulverizationByInterventionMethod extends Method
{
}