package Ontology;
import java.util.ArrayList;

import java.sql.Time;
public class SyrupFormulation extends LiquidFormulation
{
ArrayList<SweeteningAgent>  sweeteningagentproperty = new ArrayList<SweeteningAgent>();
ArrayList<ThickeningAgent>  thickeningagentproperty = new ArrayList<ThickeningAgent>();
public ArrayList<SweeteningAgent> getSweeteningagentproperty
{
return this.sweeteningagentproperty;
}
public void setSweeteningagentproperty( ArrayList<SweeteningAgent> SweeteningAgentProperty)
{
this.sweeteningagentproperty = sweeteningagentproperty;}

public ArrayList<ThickeningAgent> getThickeningagentproperty
{
return this.thickeningagentproperty;
}
public void setThickeningagentproperty( ArrayList<ThickeningAgent> ThickeningAgentProperty)
{
this.thickeningagentproperty = thickeningagentproperty;}

}