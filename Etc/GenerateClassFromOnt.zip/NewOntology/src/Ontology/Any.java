package Ontology;
import java.util.ArrayList;

import java.sql.Time;
public class Any
{
String  nameproperty;
public String  getNameproperty()
{
return this.nameproperty;
}public void setNameproperty ( String nameproperty)
{
this.nameproperty = nameproperty;
}

}