package Ontology;
import java.util.ArrayList;

import java.sql.Time;
public class Hydrolysis extends Solvolysis
{
Water  reactant;
public Water  getReactant()
{
return this.reactant;
}public void setReactant ( Water reactant)
{
this.reactant = reactant;
}

}