package Ontology;
import java.util.ArrayList;

import java.sql.Time;
public class TabletFormulation extends SolidFormulation
{
ArrayList<Diluent>  diluentfunction = new ArrayList<Diluent>();
ArrayList<Disintegrant>  disintegrantfunction = new ArrayList<Disintegrant>();
ArrayList<Lubricant>  lubricantfunction = new ArrayList<Lubricant>();
ArrayList<Binder>  binderfunction = new ArrayList<Binder>();
ArrayList<Glidant>  glidantfunction = new ArrayList<Glidant>();
ArrayList<DissolutionRetardant>  dissolutionretardantfunction = new ArrayList<DissolutionRetardant>();
ArrayList<Antiadherant>  antiadherantfunction = new ArrayList<Antiadherant>();
ArrayList<WettingAgent>  wettingagentfunction = new ArrayList<WettingAgent>();
ArrayList<GranulatingAgent>  granulatingagentfunction = new ArrayList<GranulatingAgent>();
ArrayList<Adherant>  adherantfunction = new ArrayList<Adherant>();
ArrayList<Sorbent>  sorbentfunction = new ArrayList<Sorbent>();
ArrayList<CoatingAgent>  coatingagentfunction = new ArrayList<CoatingAgent>();
public ArrayList<Diluent> getDiluentfunction
{
return this.diluentfunction;
}
public void setDiluentfunction( ArrayList<Diluent> DiluentFunction)
{
this.diluentfunction = diluentfunction;}

public ArrayList<Disintegrant> getDisintegrantfunction
{
return this.disintegrantfunction;
}
public void setDisintegrantfunction( ArrayList<Disintegrant> DisintegrantFunction)
{
this.disintegrantfunction = disintegrantfunction;}

public ArrayList<Lubricant> getLubricantfunction
{
return this.lubricantfunction;
}
public void setLubricantfunction( ArrayList<Lubricant> LubricantFunction)
{
this.lubricantfunction = lubricantfunction;}

public ArrayList<Binder> getBinderfunction
{
return this.binderfunction;
}
public void setBinderfunction( ArrayList<Binder> BinderFunction)
{
this.binderfunction = binderfunction;}

public ArrayList<Glidant> getGlidantfunction
{
return this.glidantfunction;
}
public void setGlidantfunction( ArrayList<Glidant> GlidantFunction)
{
this.glidantfunction = glidantfunction;}

public ArrayList<DissolutionRetardant> getDissolutionretardantfunction
{
return this.dissolutionretardantfunction;
}
public void setDissolutionretardantfunction( ArrayList<DissolutionRetardant> DissolutionRetardantFunction)
{
this.dissolutionretardantfunction = dissolutionretardantfunction;}

public ArrayList<Antiadherant> getAntiadherantfunction
{
return this.antiadherantfunction;
}
public void setAntiadherantfunction( ArrayList<Antiadherant> AntiadherantFunction)
{
this.antiadherantfunction = antiadherantfunction;}

public ArrayList<WettingAgent> getWettingagentfunction
{
return this.wettingagentfunction;
}
public void setWettingagentfunction( ArrayList<WettingAgent> WettingAgentFunction)
{
this.wettingagentfunction = wettingagentfunction;}

public ArrayList<GranulatingAgent> getGranulatingagentfunction
{
return this.granulatingagentfunction;
}
public void setGranulatingagentfunction( ArrayList<GranulatingAgent> GranulatingAgentFunction)
{
this.granulatingagentfunction = granulatingagentfunction;}

public ArrayList<Adherant> getAdherantfunction
{
return this.adherantfunction;
}
public void setAdherantfunction( ArrayList<Adherant> AdherantFunction)
{
this.adherantfunction = adherantfunction;}

public ArrayList<Sorbent> getSorbentfunction
{
return this.sorbentfunction;
}
public void setSorbentfunction( ArrayList<Sorbent> SorbentFunction)
{
this.sorbentfunction = sorbentfunction;}

public ArrayList<CoatingAgent> getCoatingagentfunction
{
return this.coatingagentfunction;
}
public void setCoatingagentfunction( ArrayList<CoatingAgent> CoatingAgentFunction)
{
this.coatingagentfunction = coatingagentfunction;}

}