package Ontology;
import java.util.ArrayList;

import java.sql.Time;
public class Tablet extends SolidDosageForm
{
}