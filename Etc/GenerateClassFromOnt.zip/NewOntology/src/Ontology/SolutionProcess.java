package Ontology;
import java.util.ArrayList;

import java.sql.Time;
public class SolutionProcess extends Process
{
WetMixing  unitoperationproperty;
public WetMixing  getUnitoperationproperty()
{
return this.unitoperationproperty;
}public void setUnitoperationproperty ( WetMixing unitoperationproperty)
{
this.unitoperationproperty = unitoperationproperty;
}

}