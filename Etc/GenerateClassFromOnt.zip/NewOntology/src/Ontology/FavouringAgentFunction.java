package Ontology;
import java.util.ArrayList;

import java.sql.Time;
public class FavouringAgentFunction extends CompoundFunction
{
}