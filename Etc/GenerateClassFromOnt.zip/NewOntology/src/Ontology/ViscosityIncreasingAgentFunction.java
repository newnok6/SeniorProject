package Ontology;
import java.util.ArrayList;

import java.sql.Time;
public class ViscosityIncreasingAgentFunction extends CompoundFunction
{
}