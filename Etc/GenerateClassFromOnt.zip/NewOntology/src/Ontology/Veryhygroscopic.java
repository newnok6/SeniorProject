package Ontology;
import java.util.ArrayList;

import java.sql.Time;
public class Veryhygroscopic extends Hygroscopicity
{
String  weightincrease;
float  weightincrease = 15f;
public String  getWeightincrease()
{
return this.weightincrease;
}public void setWeightincrease ( String weightincrease)
{
this.weightincrease = weightincrease;
}

public float  getWeightincrease()
{
return this.weightincrease;
}public void setWeightincrease ( float weightincrease)
{
this.weightincrease = weightincrease;
}

}