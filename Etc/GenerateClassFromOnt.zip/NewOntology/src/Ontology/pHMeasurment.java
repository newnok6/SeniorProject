package Ontology;
import java.util.ArrayList;

import java.sql.Time;
public class pHMeasurment extends QualityControl
{
float  valueproperty;
public float  getValue()
{
return this.valueproperty;
}public void setValue ( float valueproperty)
{
this.valueproperty = valueproperty;
}

}