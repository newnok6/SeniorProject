package Ontology;
import java.util.ArrayList;

import java.sql.Time;
public class WetGranulation extends Granulation
{
}