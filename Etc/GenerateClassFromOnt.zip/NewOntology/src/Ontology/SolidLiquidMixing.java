package Ontology;
import java.util.ArrayList;

import java.sql.Time;
public class SolidLiquidMixing extends Mixing
{
}