package Ontology;
import java.util.ArrayList;

import java.sql.Time;
public class CompoundFunction extends Any
{
float  maxconcentrationproperty;
float  minconcentrationproperty;
public float  getMaxconcentrationproperty()
{
return this.maxconcentrationproperty;
}public void setMaxconcentrationproperty ( float maxconcentrationproperty)
{
this.maxconcentrationproperty = maxconcentrationproperty;
}

public float  getMinconcentrationproperty()
{
return this.minconcentrationproperty;
}public void setMinconcentrationproperty ( float minconcentrationproperty)
{
this.minconcentrationproperty = minconcentrationproperty;
}

}