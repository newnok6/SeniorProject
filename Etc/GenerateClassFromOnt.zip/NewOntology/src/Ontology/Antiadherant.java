package Ontology;
import java.util.ArrayList;

import java.sql.Time;
public class Antiadherant
{
Substance  substance;
AntiadherantFunction  antiadherantfunction;
public Substance  getSubstance()
{
return this.substance;
}public void setSubstance ( Substance substance)
{
this.substance = substance;
}

public AntiadherantFunction  getAntiadherantfunction()
{
return this.antiadherantfunction;
}public void setAntiadherantfunction ( AntiadherantFunction antiadherantfunction)
{
this.antiadherantfunction = antiadherantfunction;
}

}