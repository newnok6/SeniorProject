package Ontology;
import java.util.ArrayList;

import java.sql.Time;
public class DegradationMechanism extends Any
{
Matter  reactant;
public Matter  getReactant()
{
return this.reactant;
}public void setReactant ( Matter reactant)
{
this.reactant = reactant;
}

}