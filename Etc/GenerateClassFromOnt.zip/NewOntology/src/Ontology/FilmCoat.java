package Ontology;
import java.util.ArrayList;

import java.sql.Time;
public class FilmCoat extends CoatingProcess
{
}