package Ontology;
import java.util.ArrayList;

import java.sql.Time;
public class SeivingMethod extends SizeReductionMethod
{
Integer  numberofseive;
public Integer  getNumberofseive()
{
return this.numberofseive;
}public void setNumberofseive ( Integer numberofseive)
{
this.numberofseive = numberofseive;
}

}