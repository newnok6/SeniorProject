package Ontology;
import java.util.ArrayList;

import java.sql.Time;
public class SweeteningAgent
{
Substance  substance;
SweeteningAgentProperty  sweeteningagentproperty;
public Substance  getSubstance()
{
return this.substance;
}public void setSubstance ( Substance substance)
{
this.substance = substance;
}

public SweeteningAgentProperty  getSweeteningagentproperty()
{
return this.sweeteningagentproperty;
}public void setSweeteningagentproperty ( SweeteningAgentProperty sweeteningagentproperty)
{
this.sweeteningagentproperty = sweeteningagentproperty;
}

}