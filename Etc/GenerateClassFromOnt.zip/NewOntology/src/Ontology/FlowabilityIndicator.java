package Ontology;
import java.util.ArrayList;

import java.sql.Time;
public class FlowabilityIndicator extends Any
{
float  maximumvalueproperty;
float  minimumvalueproperty;
public float  getMaximumvalueproperty()
{
return this.maximumvalueproperty;
}public void setMaximumvalueproperty ( float maximumvalueproperty)
{
this.maximumvalueproperty = maximumvalueproperty;
}

public float  getMinimumvalueproperty()
{
return this.minimumvalueproperty;
}public void setMinimumvalueproperty ( float minimumvalueproperty)
{
this.minimumvalueproperty = minimumvalueproperty;
}

}