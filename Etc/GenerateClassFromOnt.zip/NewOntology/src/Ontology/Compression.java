package Ontology;
import java.util.ArrayList;

import java.sql.Time;
public class Compression extends UnitOperation
{
float  weightproperty;
Hardness  hardnessproperty;
public float  getWeightproperty()
{
return this.weightproperty;
}public void setWeightproperty ( float weightproperty)
{
this.weightproperty = weightproperty;
}

public Hardness  getHardnessproperty()
{
return this.hardnessproperty;
}public void setHardnessproperty ( Hardness hardnessproperty)
{
this.hardnessproperty = hardnessproperty;
}

}