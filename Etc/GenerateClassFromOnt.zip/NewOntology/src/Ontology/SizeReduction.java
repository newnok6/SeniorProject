package Ontology;
import java.util.ArrayList;

import java.sql.Time;
public class SizeReduction extends UnitOperation
{
SeivingMethod  sizereductionmethod;
public SeivingMethod  getSizereductionmethod()
{
return this.sizereductionmethod;
}public void setSizereductionmethod ( SeivingMethod sizereductionmethod)
{
this.sizereductionmethod = sizereductionmethod;
}

}