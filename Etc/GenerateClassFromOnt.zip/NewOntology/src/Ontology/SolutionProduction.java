package Ontology;
import java.util.ArrayList;

import java.sql.Time;
public class SolutionProduction extends PharmaceuticalProduction
{
SolutionProcess  processproperty;
SolutionFormulation  formulationproperty;
public SolutionProcess  getProcessproperty()
{
return this.processproperty;
}public void setProcessproperty ( SolutionProcess processproperty)
{
this.processproperty = processproperty;
}

public SolutionFormulation  getFormulationproperty()
{
return this.formulationproperty;
}public void setFormulationproperty ( SolutionFormulation formulationproperty)
{
this.formulationproperty = formulationproperty;
}

}