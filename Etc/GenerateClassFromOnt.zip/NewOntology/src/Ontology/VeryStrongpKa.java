package Ontology;
import java.util.ArrayList;

import java.sql.Time;
public class VeryStrongpKa extends pKa
{
float  maximumpkaproperty = 0f;
float  minimalpka;
public float  getMaximumpkaproperty()
{
return this.maximumpkaproperty;
}public void setMaximumpkaproperty ( float maximumpkaproperty)
{
this.maximumpkaproperty = maximumpkaproperty;
}

public float  getMinimalpka()
{
return this.minimalpka;
}public void setMinimalpka ( float minimalpka)
{
this.minimalpka = minimalpka;
}

}