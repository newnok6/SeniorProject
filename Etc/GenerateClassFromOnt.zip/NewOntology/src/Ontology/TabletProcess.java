package Ontology;
import java.util.ArrayList;

import java.sql.Time;
public class TabletProcess extends Process
{
Mixing  unitoperationproperty;
Compression  unitoperationproperty;
public Mixing  getUnitoperationproperty()
{
return this.unitoperationproperty;
}public void setUnitoperationproperty ( Mixing unitoperationproperty)
{
this.unitoperationproperty = unitoperationproperty;
}

public Compression  getUnitoperationproperty()
{
return this.unitoperationproperty;
}public void setUnitoperationproperty ( Compression unitoperationproperty)
{
this.unitoperationproperty = unitoperationproperty;
}

}