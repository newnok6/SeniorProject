package test;

/**
 * Created by admin on 5/19/14 AD.
 */
public class subclass extends superclass {
    String makky;

    public String getMakky() {
        return makky;
    }

    public void setMakky(String makky) {
        this.makky = makky;
    }
}
